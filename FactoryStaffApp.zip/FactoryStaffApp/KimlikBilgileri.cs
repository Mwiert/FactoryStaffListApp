﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NYPvize_180601048_MertSahin
{
    public class KimlikBilgileri
    {
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public ulong telefonNo { get; set; }
        public string Email { get; set; }
        public ulong TcNo { get; set; }
    }
}

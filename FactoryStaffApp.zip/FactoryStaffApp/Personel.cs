﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NYPvize_180601048_MertSahin
{
    public class Personel
    {
        public KimlikBilgileri KimlikBilgi = new KimlikBilgileri();
        public int PersonelNo { get; set; }
        public string Nitelik { get; set; }
        public string Birim { get; set; }
    }
}

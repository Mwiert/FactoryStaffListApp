﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NYPvize_180601048_MertSahin
{
    class Fabrika
    {
        public void PrsnEkle(Personel Kisi)
        {
            PersonelListe.Add(Kisi);
        }
        public List<Personel> PersonelListe = new List<Personel>();
        public string PersonelListele(int i)
        {
            Personel prsnlListe = PersonelListe[i];
            string PersonelBilgileri = "Personel No: " + prsnlListe.PersonelNo +
                               "  İsim: " + prsnlListe.KimlikBilgi.Ad +
                               "Soyisim: " + prsnlListe.KimlikBilgi.Soyad +
                               "Birim: " + prsnlListe.Birim +
                                "Nitelik: " + prsnlListe.Nitelik;
            return PersonelBilgileri;
        }
        public void PrsnlCikar(int prsnlNum)
        {
            for (int i = 0; i < PersonelListe.Count; i++)
            {
                Personel PrsnlCikar = PersonelListe[i];
                if (prsnlNum == PrsnlCikar.PersonelNo)
                {
                    PersonelListe.RemoveAt(i);
                }
            }
        }
    }
}

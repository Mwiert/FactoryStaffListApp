﻿
namespace NYPvize_180601048_MertSahin
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lstvwListele = new System.Windows.Forms.ListView();
            this.ustPanel = new System.Windows.Forms.Panel();
            this.pctrBakircay = new System.Windows.Forms.PictureBox();
            this.ustPanelic = new System.Windows.Forms.Panel();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.lblEkle = new System.Windows.Forms.Label();
            this.btnListele = new System.Windows.Forms.Button();
            this.ustPanelicAlt = new System.Windows.Forms.Panel();
            this.txtbxCikar = new System.Windows.Forms.MaskedTextBox();
            this.btnPrsnlCikar = new System.Windows.Forms.Button();
            this.lblprsnlNocikar = new System.Windows.Forms.Label();
            this.lblPrsnlCikar = new System.Windows.Forms.Label();
            this.txtTcNo = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.MaskedTextBox();
            this.txtPrsnlNo = new System.Windows.Forms.MaskedTextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTel = new System.Windows.Forms.Label();
            this.btnEkle = new System.Windows.Forms.Button();
            this.lblTcNo = new System.Windows.Forms.Label();
            this.txtNitelik = new System.Windows.Forms.TextBox();
            this.txtBirim = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.lblNitelik = new System.Windows.Forms.Label();
            this.lblBirim = new System.Windows.Forms.Label();
            this.lblPrsnelNo = new System.Windows.Forms.Label();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.BildirimNotifi = new System.Windows.Forms.NotifyIcon(this.components);
            this.lblNot = new System.Windows.Forms.Label();
            this.ustPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctrBakircay)).BeginInit();
            this.ustPanelic.SuspendLayout();
            this.ustPanelicAlt.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstvwListele
            // 
            this.lstvwListele.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstvwListele.HideSelection = false;
            this.lstvwListele.Location = new System.Drawing.Point(12, 295);
            this.lstvwListele.Name = "lstvwListele";
            this.lstvwListele.Size = new System.Drawing.Size(1068, 364);
            this.lstvwListele.TabIndex = 5;
            this.lstvwListele.UseCompatibleStateImageBehavior = false;
            this.lstvwListele.View = System.Windows.Forms.View.List;
            // 
            // ustPanel
            // 
            this.ustPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ustPanel.Controls.Add(this.pctrBakircay);
            this.ustPanel.Location = new System.Drawing.Point(12, 12);
            this.ustPanel.Name = "ustPanel";
            this.ustPanel.Size = new System.Drawing.Size(1068, 277);
            this.ustPanel.TabIndex = 4;
            // 
            // pctrBakircay
            // 
            this.pctrBakircay.Image = global::NYPvize_180601048_MertSahin.Properties.Resources.bakircayedu;
            this.pctrBakircay.InitialImage = ((System.Drawing.Image)(resources.GetObject("pctrBakircay.InitialImage")));
            this.pctrBakircay.Location = new System.Drawing.Point(6, 23);
            this.pctrBakircay.Name = "pctrBakircay";
            this.pctrBakircay.Size = new System.Drawing.Size(140, 145);
            this.pctrBakircay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pctrBakircay.TabIndex = 0;
            this.pctrBakircay.TabStop = false;
            // 
            // ustPanelic
            // 
            this.ustPanelic.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.ustPanelic.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ustPanelic.Controls.Add(this.txtAd);
            this.ustPanelic.Controls.Add(this.lblEkle);
            this.ustPanelic.Controls.Add(this.btnListele);
            this.ustPanelic.Controls.Add(this.ustPanelicAlt);
            this.ustPanelic.Controls.Add(this.txtTcNo);
            this.ustPanelic.Controls.Add(this.txtTel);
            this.ustPanelic.Controls.Add(this.txtPrsnlNo);
            this.ustPanelic.Controls.Add(this.txtEmail);
            this.ustPanelic.Controls.Add(this.lblEmail);
            this.ustPanelic.Controls.Add(this.lblTel);
            this.ustPanelic.Controls.Add(this.btnEkle);
            this.ustPanelic.Controls.Add(this.lblTcNo);
            this.ustPanelic.Controls.Add(this.txtNitelik);
            this.ustPanelic.Controls.Add(this.txtBirim);
            this.ustPanelic.Controls.Add(this.txtSoyad);
            this.ustPanelic.Controls.Add(this.lblNitelik);
            this.ustPanelic.Controls.Add(this.lblBirim);
            this.ustPanelic.Controls.Add(this.lblPrsnelNo);
            this.ustPanelic.Controls.Add(this.lblSoyad);
            this.ustPanelic.Controls.Add(this.lblAd);
            this.ustPanelic.Location = new System.Drawing.Point(161, 12);
            this.ustPanelic.Name = "ustPanelic";
            this.ustPanelic.Size = new System.Drawing.Size(916, 265);
            this.ustPanelic.TabIndex = 1;
            // 
            // txtAd
            // 
            this.txtAd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAd.Location = new System.Drawing.Point(117, 61);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(128, 20);
            this.txtAd.TabIndex = 2;
            this.txtAd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAd_KeyPress);
            // 
            // lblEkle
            // 
            this.lblEkle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEkle.AutoSize = true;
            this.lblEkle.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEkle.Location = new System.Drawing.Point(286, 4);
            this.lblEkle.Name = "lblEkle";
            this.lblEkle.Size = new System.Drawing.Size(172, 22);
            this.lblEkle.TabIndex = 29;
            this.lblEkle.Text = "PERSONEL EKLE";
            // 
            // btnListele
            // 
            this.btnListele.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnListele.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnListele.Location = new System.Drawing.Point(784, 175);
            this.btnListele.Name = "btnListele";
            this.btnListele.Size = new System.Drawing.Size(116, 57);
            this.btnListele.TabIndex = 10;
            this.btnListele.Text = "LİSTELE";
            this.btnListele.UseVisualStyleBackColor = true;
            this.btnListele.Click += new System.EventHandler(this.btnListele_Click);
            // 
            // ustPanelicAlt
            // 
            this.ustPanelicAlt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ustPanelicAlt.Controls.Add(this.lblNot);
            this.ustPanelicAlt.Controls.Add(this.txtbxCikar);
            this.ustPanelicAlt.Controls.Add(this.btnPrsnlCikar);
            this.ustPanelicAlt.Controls.Add(this.lblprsnlNocikar);
            this.ustPanelicAlt.Controls.Add(this.lblPrsnlCikar);
            this.ustPanelicAlt.Location = new System.Drawing.Point(3, 160);
            this.ustPanelicAlt.Name = "ustPanelicAlt";
            this.ustPanelicAlt.Size = new System.Drawing.Size(772, 87);
            this.ustPanelicAlt.TabIndex = 46;
            // 
            // txtbxCikar
            // 
            this.txtbxCikar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxCikar.Location = new System.Drawing.Point(142, 34);
            this.txtbxCikar.Mask = "00000";
            this.txtbxCikar.Name = "txtbxCikar";
            this.txtbxCikar.Size = new System.Drawing.Size(122, 20);
            this.txtbxCikar.TabIndex = 11;
            this.txtbxCikar.ValidatingType = typeof(int);
            // 
            // btnPrsnlCikar
            // 
            this.btnPrsnlCikar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrsnlCikar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPrsnlCikar.Location = new System.Drawing.Point(358, 29);
            this.btnPrsnlCikar.Name = "btnPrsnlCikar";
            this.btnPrsnlCikar.Size = new System.Drawing.Size(187, 28);
            this.btnPrsnlCikar.TabIndex = 12;
            this.btnPrsnlCikar.Text = "PERSONEL ÇIKAR";
            this.btnPrsnlCikar.UseVisualStyleBackColor = true;
            this.btnPrsnlCikar.Click += new System.EventHandler(this.btnPrsnlCikar_Click);
            // 
            // lblprsnlNocikar
            // 
            this.lblprsnlNocikar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblprsnlNocikar.AutoSize = true;
            this.lblprsnlNocikar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblprsnlNocikar.Location = new System.Drawing.Point(6, 34);
            this.lblprsnlNocikar.Name = "lblprsnlNocikar";
            this.lblprsnlNocikar.Size = new System.Drawing.Size(107, 17);
            this.lblprsnlNocikar.TabIndex = 24;
            this.lblprsnlNocikar.Text = "Personel No :";
            // 
            // lblPrsnlCikar
            // 
            this.lblPrsnlCikar.AutoSize = true;
            this.lblPrsnlCikar.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPrsnlCikar.Location = new System.Drawing.Point(283, 0);
            this.lblPrsnlCikar.Name = "lblPrsnlCikar";
            this.lblPrsnlCikar.Size = new System.Drawing.Size(179, 22);
            this.lblPrsnlCikar.TabIndex = 23;
            this.lblPrsnlCikar.Text = "PERSONEL ÇIKAR";
            // 
            // txtTcNo
            // 
            this.txtTcNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTcNo.Location = new System.Drawing.Point(467, 88);
            this.txtTcNo.Name = "txtTcNo";
            this.txtTcNo.Size = new System.Drawing.Size(123, 20);
            this.txtTcNo.TabIndex = 7;
            this.txtTcNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTcNo_KeyPress);
            // 
            // txtTel
            // 
            this.txtTel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTel.Location = new System.Drawing.Point(116, 118);
            this.txtTel.Mask = "(999) 000-0000";
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(129, 20);
            this.txtTel.TabIndex = 4;
            // 
            // txtPrsnlNo
            // 
            this.txtPrsnlNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPrsnlNo.Location = new System.Drawing.Point(116, 33);
            this.txtPrsnlNo.Mask = "00000";
            this.txtPrsnlNo.Name = "txtPrsnlNo";
            this.txtPrsnlNo.RejectInputOnFirstFailure = true;
            this.txtPrsnlNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtPrsnlNo.Size = new System.Drawing.Size(129, 20);
            this.txtPrsnlNo.TabIndex = 1;
            this.txtPrsnlNo.ValidatingType = typeof(int);
            // 
            // txtEmail
            // 
            this.txtEmail.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail.Location = new System.Drawing.Point(467, 116);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(154, 20);
            this.txtEmail.TabIndex = 8;
            // 
            // lblEmail
            // 
            this.lblEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEmail.Location = new System.Drawing.Point(386, 116);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(75, 17);
            this.lblEmail.TabIndex = 41;
            this.lblEmail.Text = "E-Posta :";
            // 
            // lblTel
            // 
            this.lblTel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTel.AutoSize = true;
            this.lblTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTel.Location = new System.Drawing.Point(37, 121);
            this.lblTel.Name = "lblTel";
            this.lblTel.Size = new System.Drawing.Size(73, 17);
            this.lblTel.TabIndex = 40;
            this.lblTel.Text = "Telefon :";
            // 
            // btnEkle
            // 
            this.btnEkle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEkle.Location = new System.Drawing.Point(741, 43);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(159, 57);
            this.btnEkle.TabIndex = 9;
            this.btnEkle.Text = "PERSONEL EKLE";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // lblTcNo
            // 
            this.lblTcNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTcNo.AutoSize = true;
            this.lblTcNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTcNo.Location = new System.Drawing.Point(358, 88);
            this.lblTcNo.Name = "lblTcNo";
            this.lblTcNo.Size = new System.Drawing.Size(103, 17);
            this.lblTcNo.TabIndex = 38;
            this.lblTcNo.Text = "Tc Kimlik No:";
            // 
            // txtNitelik
            // 
            this.txtNitelik.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtNitelik.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNitelik.Location = new System.Drawing.Point(467, 62);
            this.txtNitelik.Name = "txtNitelik";
            this.txtNitelik.Size = new System.Drawing.Size(123, 20);
            this.txtNitelik.TabIndex = 6;
            this.txtNitelik.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNitelik_KeyPress);
            // 
            // txtBirim
            // 
            this.txtBirim.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtBirim.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBirim.Location = new System.Drawing.Point(467, 33);
            this.txtBirim.Name = "txtBirim";
            this.txtBirim.Size = new System.Drawing.Size(123, 20);
            this.txtBirim.TabIndex = 5;
            this.txtBirim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBirim_KeyPress);
            // 
            // txtSoyad
            // 
            this.txtSoyad.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
            this.txtSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSoyad.Location = new System.Drawing.Point(116, 91);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(129, 20);
            this.txtSoyad.TabIndex = 3;
            this.txtSoyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoyad_KeyPress);
            // 
            // lblNitelik
            // 
            this.lblNitelik.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNitelik.AutoSize = true;
            this.lblNitelik.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNitelik.Location = new System.Drawing.Point(393, 62);
            this.lblNitelik.Name = "lblNitelik";
            this.lblNitelik.Size = new System.Drawing.Size(68, 17);
            this.lblNitelik.TabIndex = 33;
            this.lblNitelik.Text = "Niteliği :";
            // 
            // lblBirim
            // 
            this.lblBirim.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBirim.AutoSize = true;
            this.lblBirim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBirim.Location = new System.Drawing.Point(407, 36);
            this.lblBirim.Name = "lblBirim";
            this.lblBirim.Size = new System.Drawing.Size(54, 17);
            this.lblBirim.TabIndex = 32;
            this.lblBirim.Text = "Birim :";
            // 
            // lblPrsnelNo
            // 
            this.lblPrsnelNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPrsnelNo.AutoSize = true;
            this.lblPrsnelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPrsnelNo.Location = new System.Drawing.Point(9, 34);
            this.lblPrsnelNo.Name = "lblPrsnelNo";
            this.lblPrsnelNo.Size = new System.Drawing.Size(107, 17);
            this.lblPrsnelNo.TabIndex = 31;
            this.lblPrsnelNo.Text = "Personel No :";
            // 
            // lblSoyad
            // 
            this.lblSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSoyad.Location = new System.Drawing.Point(47, 94);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(63, 17);
            this.lblSoyad.TabIndex = 30;
            this.lblSoyad.Text = "Soyad :";
            // 
            // lblAd
            // 
            this.lblAd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAd.AutoSize = true;
            this.lblAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAd.Location = new System.Drawing.Point(73, 62);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(37, 17);
            this.lblAd.TabIndex = 29;
            this.lblAd.Text = "Ad :";
            // 
            // BildirimNotifi
            // 
            this.BildirimNotifi.BalloonTipTitle = "NYP_VİZE";
            this.BildirimNotifi.Icon = ((System.Drawing.Icon)(resources.GetObject("BildirimNotifi.Icon")));
            this.BildirimNotifi.Text = "BildirimNotifi";
            this.BildirimNotifi.Visible = true;
            this.BildirimNotifi.BalloonTipClicked += new System.EventHandler(this.BildirimNotifi_BalloonTipClicked);
            this.BildirimNotifi.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.BildirimNotifi_MouseDoubleClick);
            // 
            // lblNot
            // 
            this.lblNot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNot.AutoSize = true;
            this.lblNot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNot.Location = new System.Drawing.Point(570, 15);
            this.lblNot.Name = "lblNot";
            this.lblNot.Size = new System.Drawing.Size(199, 45);
            this.lblNot.TabIndex = 25;
            this.lblNot.Text = "NOT!!!\r\nPERSONEL ÇIKARDIKTAN SONRA\r\n LUTFEN LİSTEYİ YENİLEYİNİZ.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 656);
            this.Controls.Add(this.ustPanelic);
            this.Controls.Add(this.lstvwListele);
            this.Controls.Add(this.ustPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Fabrika Uygulama";
            this.Load += new System.EventHandler(this.Fabrika_form_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Move += new System.EventHandler(this.Fabrika_form_Move);
            this.ustPanel.ResumeLayout(false);
            this.ustPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctrBakircay)).EndInit();
            this.ustPanelic.ResumeLayout(false);
            this.ustPanelic.PerformLayout();
            this.ustPanelicAlt.ResumeLayout(false);
            this.ustPanelicAlt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lstvwListele;
        private System.Windows.Forms.Panel ustPanel;
        private System.Windows.Forms.Panel ustPanelic;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label lblEkle;
        private System.Windows.Forms.Button btnListele;
        private System.Windows.Forms.Panel ustPanelicAlt;
        private System.Windows.Forms.MaskedTextBox txtbxCikar;
        private System.Windows.Forms.Button btnPrsnlCikar;
        private System.Windows.Forms.Label lblprsnlNocikar;
        private System.Windows.Forms.Label lblPrsnlCikar;
        private System.Windows.Forms.TextBox txtTcNo;
        private System.Windows.Forms.MaskedTextBox txtTel;
        public System.Windows.Forms.MaskedTextBox txtPrsnlNo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblTel;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Label lblTcNo;
        private System.Windows.Forms.TextBox txtNitelik;
        private System.Windows.Forms.TextBox txtBirim;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label lblNitelik;
        private System.Windows.Forms.Label lblBirim;
        private System.Windows.Forms.Label lblPrsnelNo;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.PictureBox pctrBakircay;
        private System.Windows.Forms.NotifyIcon BildirimNotifi;
        private System.Windows.Forms.Label lblNot;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tulpep.NotificationWindow;

namespace NYPvize_180601048_MertSahin
{
    public partial class Form1 : Form
    {
        Fabrika fabrikaUygulama = new Fabrika();
        public Form1()
        {
            InitializeComponent();
        }
        public void PersonelListele()
        {
            lstvwListele.Clear();
            for (int i = 0; i < fabrikaUygulama.PersonelListe.Count; i++)
            {
                lstvwListele.Items.Add(fabrikaUygulama.PersonelListele(i));
            }
        }
        private void txtAd_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yazıTipi = e.KeyChar;
            if (!Char.IsLetter(yazıTipi) && yazıTipi != 8 && yazıTipi != 46)
            {
                e.Handled = true;
            }
        }
        private void txtSoyad_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yazıTipi = e.KeyChar;
            if (!Char.IsLetter(yazıTipi) && yazıTipi != 8 && yazıTipi != 46)
            {
                e.Handled = true;
            }
        }
        private void txtBirim_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yazıTipi = e.KeyChar;
            if (!Char.IsLetter(yazıTipi) && !Char.IsWhiteSpace(yazıTipi) && yazıTipi != 8 && yazıTipi != 46)
            {
                e.Handled = true;
            }
        }
        private void txtNitelik_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yazıTipi = e.KeyChar;
            if (!Char.IsLetter(yazıTipi) && !Char.IsWhiteSpace(yazıTipi) && yazıTipi != 8 && yazıTipi != 46)
            {
                e.Handled = true;
            }
        }
        private void txtTcNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yazıTipi = e.KeyChar;
            if (!Char.IsDigit(yazıTipi) && yazıTipi != 8 && yazıTipi != 46)
            {
                e.Handled = true;
            }
        }
        private void btnPrsnlCikar_Click(object sender, EventArgs e)
        {
            int personelNumarası = Convert.ToInt32(txtbxCikar.Text);
            fabrikaUygulama.PrsnlCikar(personelNumarası);
        }
        private void btnListele_Click(object sender, EventArgs e)
        {
            PersonelListele();
        }
        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtAd.Text.Trim() == string.Empty || txtSoyad.Text.Trim() == string.Empty
                || txtBirim.Text.Trim() == string.Empty || txtNitelik.Text.Trim() == string.Empty
                || txtPrsnlNo.Text.Trim() == string.Empty || txtTel.Text.Trim() == string.Empty
                || txtTcNo.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty)
            {
                MessageBox.Show("BİLGİLER BOŞ BIRAKILAMAZ!!!!");
            }
            else
            {
                if (txtTcNo.Text.Length != 11)
                {
                    MessageBox.Show("Tc Kimlik Numarası 11 haneli olmalıdır!");
                    txtTcNo.Clear();
                    txtTcNo.Focus();
                }
                else
                {
                    Personel prsnl = new Personel();
                    prsnl.KimlikBilgi = new KimlikBilgileri();
                    prsnl.KimlikBilgi.Ad = txtAd.Text;
                    prsnl.KimlikBilgi.Soyad = txtSoyad.Text;
                    prsnl.PersonelNo = Convert.ToInt32(txtPrsnlNo.Text);
                    prsnl.Birim = txtBirim.Text;
                    prsnl.Nitelik = txtNitelik.Text;
                    fabrikaUygulama.PrsnEkle(prsnl);
                    EkranSıfırla();
                }
            }
        }
        public void EkranSıfırla()
        {
            txtAd.Text = txtSoyad.Text = txtEmail.Text = txtBirim.Text = txtNitelik.Text = txtPrsnlNo.Text = txtTel.Text = txtTcNo.Text= "";
            txtPrsnlNo.Focus();
        }
        public void popupEkle()
        {
            PopupNotifier popup = new PopupNotifier();
            popup.TitleText = "WELCOME TO FACTORY STAFF APPLICATION";
            popup.ContentText = "Github.com/mwiert";
            popup.Image = Properties.Resources.bakircayedu;
            popup.Popup();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            popupEkle();       
        }
        private void BildirimNotifi_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }
        private void BildirimNotifi_BalloonTipShown(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }
        private void BildirimNotifi_BalloonTipClicked(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }
        private void Fabrika_form_Load(object sender, EventArgs e)
        {
            popupEkle();
        }
        private void Fabrika_form_Move(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
                BildirimNotifi.ShowBalloonTip(2000, "NESNE YÖNELİMLİ PROGRAMLAMA", "HOŞGELDİNİZ", ToolTipIcon.Info);
            }
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            txtPrsnlNo.Focus();
        }
    }
}
